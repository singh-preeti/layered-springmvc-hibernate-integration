package com.example.spring;

import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class EmployeeDaoImpl implements EmployeeDao {

    public List<Employee> getEmployeeList() {
        return Arrays.asList(new Employee("1", "Sam", "IT"),
                new Employee("2", "Hero", "HR"));
    }

}
