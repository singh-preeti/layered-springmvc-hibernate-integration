package com.example.spring;

import org.apache.catalina.startup.Tomcat;

public class Application {
    public static void main(String[] args) throws Exception {

        String appBase = ".";
        Tomcat tomcat = new Tomcat();
        tomcat.getHost().setAppBase(appBase);
        tomcat.setPort(8080);
        tomcat.addWebapp("/", appBase);
        tomcat.getConnector(); // Trigger the creation of the default connector
        tomcat.start();
        tomcat.getServer().await();
    }
}
