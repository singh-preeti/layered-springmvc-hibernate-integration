package com.example.spring;

import java.util.List;

public interface EmployeeDao {

    List<Employee> getEmployeeList();
}
